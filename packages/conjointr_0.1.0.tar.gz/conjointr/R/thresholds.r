################################################################################
# Copyright (c) 2025. All rights reserved.  See the file LICENSE for
# license terms.
################################################################################

# File: thresholds.r
# Proj: conjointr
# Desc: Functions used to calculate the adoption thresholds, incentives and resistance
# Auth: Radu Tanase (RT)
# Last update: Sept 2025

################################################################################


#' Get the adoption threshold for one product profile using one MCMC draw for one respondent (or utilities already averaged)
#'
#' @param draw MCMC draw for one respondent
#' @param product product profile
#' @param predictors vector with the names of the attributes columns (including noneFALSE), except adopters
#' @param adopters list with: type = either linear or partworth, variables = adopters.variables vector with the names of the adopters columns, values = adopters.values vector with adopters levels. Should be sorted the same as the adopters variables
#' @param constrain.thresholds if the threshold should be mapped to 0-1 (values outside the range take the extremes)
#' @importFrom stats sortedXyData
#' @importFrom stats NLSstClosestX
#' @author Radu Tanase
#' @details Inspired from measuring willingness to pay from conjoint data. For an explanation of the methodology, see Miller, K. M., Hofstetter, R., Krohmer, H., & Zhang, Z. J. (2011). How Should Consumers’ Willingness to Pay Be Measured.
#' @note If adopters is partworth, the threshold is only defined if the utility is increasing in the levels. As improvement, a check could be added to see if this is the case and if not break.
.GetThreshold <- function(draw, product, predictors, adopters, constrain.thresholds){
    # Compute utility of none
    utility.none <- draw["noneTRUE"]
    if(invalid(utility.none)){
      stop("Utility of none is missing" )
    }
    # Check coefficient values exist for all predictors
    if(any(invalid(draw[predictors])) |  any(invalid(product[predictors]))){
      stop("Some predictors do not have coefficient or product values")
    }
    if(invalid(draw["adopters"])){
      stop("Coefficient for adopters is missing" )
    }

    # Compute utility of profile without adopters
    profile.utility <- sum(draw[predictors] %*% product[predictors])

    # Compute threshold if adopters is partworth
    if(adopters$type == "partworth") {
      adopters.values <- adopters$level
      adopters.variables <- paste("adopters", adopters.values, sep="")
      # Create data for inverse utility for all adopters levels
      input <- sortedXyData(x=adopters.values , y=draw[adopters.variables])
      threshold <- NLSstClosestX(input, (utility.none - profile.utility))
    }

    # Compute threshold if adopters is linear
    if(adopters$type == "linear") {
      # If the number of adopters has a negative utility of the social signal break as thresholds might not be well defined
      if(draw['adopters'] <= 0) {
        stop("Number of adopters has negative or zero utility. Cannot compute threshold.")
      }

      # Compute wtp
      threshold <- (utility.none - profile.utility)/draw['adopters']
      # Bound it to 0-1
      if(constrain.thresholds==TRUE){
        if(threshold < 0) threshold <- 0
        if(threshold > 1) threshold <- 1
      }
    }
    # Return
    threshold
}

#' Get the adoption threshold for multiple profile using data with one row per respondent (either ground truth or if estimated already averaged over MCMC iterations)
#'
#' @param data data table with the partworth utilities per respondent
#' @param profiles.matrix matrix with all the product profiles
#' @param predictors vector with the names of the attributes columns, except price
#' @param adopters list with: type = either linear or partworth, variables = adopters.variables vector with the names of the adopters columns, values = adopters.values vector with adopters levels. Should be sorted the same as the adopters variables
#' @param constrain.thresholds if the thresholds should be mapped to 0-1 (values outside the range take the extremes). Default is TRUE.
#' @author Radu Tanase
#' @details Inspired from measuring willingness to pay from conjoint data. For an explanation of the methodology, see Miller, K. M., Hofstetter, R., Krohmer, H., & Zhang, Z. J. (2011). How Should Consumers’ Willingness to Pay Be Measured.
#' @export
GetThresholds <- function(data, profiles.matrix, predictors, adopters, constrain.thresholds=TRUE){
  # Compute willingness to pay for each profile
  res.betadraw <- foreach(j = 1:nrow(profiles.matrix)) %dopar% {
    # Define the product
    product = profiles.matrix[j,]
    product.name <- row.names(profiles.matrix)[j]
    tmp.threshold <- apply(data, 1, .GetThreshold, product, predictors, adopters, constrain.thresholds)
    data.table(resp.id = data$resp.id, profile = product.name, threshold=tmp.threshold)
  }
  rbindlist(res.betadraw)
}

#' Get incentive
#' Compute the incentive needed to adopt a given product in the absence of social signal
#' @param draw vector with the partworth utilties (averaged over MCMC draws) for a given respondent
#' @param product vector with the product attributes in dummy coding
#' @param predictors vector with the names of the predictors (attribute levels) (make sure adopters is not included)
#' @author Radu Tanase
#' @export
GetIncentive <- function(draw, product, predictors){
  # Compute utility of none
  utility.none <- draw["noneTRUE"]
  if(invalid(utility.none)){
    stop("Utility of none is missing" )
  }
  # Check coefficient values exist for all predictors
  if(any(invalid(draw[predictors])) |  any(invalid(product[predictors]))){
    stop("Some predictors do not have coefficient or product values")
  }
  # Compute utility of profile without price
  profile.utility <- sum(draw[predictors] %*% product[predictors])

  # Compute incentive
  utility.none - profile.utility
}

#' GetIncetives
#' Compute the incentive needed to adopt each product in the absence of social signal
#' @param data data.table with the partworth utilities (averaged over MCMC draws) for each respondent
#' @param profiles.matrix matrix with the product attributes in dummy coding
#' @param predictors vector with the names of the predictors (attribute levels) (make sure adopters is not included)
#' @author Radu Tanase
#' @export
GetIncentives <- function(data, profiles.matrix, predictors){
  # Compute willingness to pay for each profile
  res <- foreach(j = 1:nrow(profiles.matrix)) %dopar% {
    # Define the product
    product.name <- row.names(profiles.matrix)[j]
    # Extract dummy coding for the product
    product = profiles.matrix[j,]
    # Calculate incentives for all respondents
    incentives <- apply(data, 1, GetIncentive, product, predictors)
    # Return
    data.table(resp.id = data$resp.id, profile = product.name, incentive = incentives)
  }
  rbindlist(res)
}

#' GetResistance
#' Function to compute the resistance to adoption (difference between the utility of the none option and the attribute utility)
#' @param coefs Data table with the partworth utilities
#' @param profiles.matrix Matrix with the dummy coding of the profiles
#' @author Radu Tanase
#' @export
GetResistance <- function(coefs, profiles.matrix){
  # Take the average over the MCMC draws
  coefs <- coefs[, lapply(.SD, mean), by=resp.id]

  res <- foreach(i = unique(coefs$resp.id)) %dopar% {
    # Subset betadraws
    betas <-  coefs[resp.id==i, -"resp.id"]

    # Extract utility of the none option
    utility.none <- betas[, noneTRUE]
    if(invalid(utility.none)){
      stop("Utility of none is missing" )
    }

    # Utility of adopters
    utility.adopters <- betas[, adopters]
    if(invalid(utility.adopters)){
      stop("Utility of adopters is missing" )
    }

    # Calculate attribute utilities
    attribute.utilities <- profiles.matrix %*% t(as.matrix(betas[, colnames(profiles.matrix), with=FALSE]))

    # Return
    data.table(resp.id = i, product = row.names(attribute.utilities), resistance = utility.none - attribute.utilities[, 1], beta_si = utility.adopters)
  }
  rbindlist(res)
}
