################################################################################
# Copyright (c) 2025. All rights reserved.  See the file LICENSE for
# license terms.
################################################################################

# File: functions.r
# Proj: conjointr
# Desc: Functions used to estimate conjoint data using the choicemodelr implementation
#       of hierarchical bayes.
# Auth: Radu Tanase (RT)
# Last update: Sept 2025

################################################################################

#' Load default packages
#'
#' @param x object to check if it is invalid
#'
#' @import data.table
#' @import foreach
#' @import doMC
#' @import parallel
#' @importFrom stats model.matrix
LoadDefaultPackages <- function(){
    print("default packages loaded")
}

#' Fit a hierarchical bayes model to conjoint data in processed sawtooth format
#'
#' @param data data table in sawtooth format. Needs to contain the resp.id, ques, alt and choice (with these exact namings. The factors should be coded as factors, the numeric as numeric. There should be no none option. Rather, in the choice column there should be a value on the first row of each question coded as (nr of choices + 1)
#' @param data.respondent data table with the "demographics". One of the columns should contain the resp.id, named exactly in this way
#' @importFrom ChoiceModelR choicemodelr
#' @import data.table
#' @export
#' @author Radu Tanase
FitHB <- function(data, data.respondent=NULL, get.coefs.ref.level = TRUE, mc.cores = 4, mcmc=list(R=5000, use=4000), options = list(none=TRUE, save=TRUE, keep=10, contrasts = c("contr.sum")), ...){
    # Get xcoding (1 for numeric, 0 for factors)
    xcoding <- as.numeric(!sapply(data, is.factor))
    names(xcoding) <- colnames(data)
    # Process and convert the factor variables
    col.factor <- names(data)[sapply(data, is.factor)]
    factor.levels <- foreach(i = col.factor) %do% {
      # Get levels
      tmp.levels <- levels(data[[i]])
      # Remove the values not present
      tmp.levels <- tmp.levels[tmp.levels %in% unique(data[[i]])]
      # Get the reference level
      tmp.ref.level <- tmp.levels[length(tmp.levels)] # The reference level seems to be the last
      # Drop level 0 which corresponds to the none option. This must not be the reference
      if(tmp.ref.level==0){
        stop(paste("The reference level for", i, "is 0"))
      }
      tmp.levels <- tmp.levels[tmp.levels!=0]
      # Convert to numeric
      data[[i]] <- as.character(ifelse(data[[i]]==0, 0, paste("C", data[[i]]))) # Convert from factor to string such that we don't have issues. Do this only for the non-0 level (which corresponds to none)
      # Add C such that there's no error when factor levels are low integers (e.g., 1,2).
      num.value <- 1
      for(k in tmp.levels) {
        data[[i]][data[[i]]==paste("C", k)] <- num.value
        num.value <- num.value + 1
      }
      data[[i]] <- as.numeric(data[[i]])
      tmp <- list(variable=i, levels=tmp.levels, ref_level=tmp.ref.level, variable_name=paste(i, tmp.levels, sep=""), ref_level_name=paste(i, tmp.ref.level, sep=""))
    }
    names(factor.levels) <- col.factor
    var.order <- names(data)[!names(data) %in% c("resp.id", "ques", "alt", "choice")]
    # Set the variable order: First factors, than numeric
    var.order <- c(col.factor, var.order[!var.order %in% col.factor])
    # Adjust xcoding accordingly
    xcoding <- xcoding[var.order]

    # Reorder columns according to the specified variable order
    data <- data[, c("resp.id", "ques", "alt", var.order, "choice"), with=FALSE]

    # Put rows in the right order
    data <- data[order(-resp.id, -ques, choice, decreasing=TRUE)]

    # Convert to dataframe
    data <- data.frame(data)
    if(invalid(data.respondent)){
        fit.hb <- ChoiceModelR:::choicemodelr(data = data, xcoding = xcoding, mcmc=mcmc, options = options, ...)
    } else {
        data.respondent = data.frame(data.respondent[order(-resp.id, decreasing=TRUE)])
        data.respondent$resp.id <- NULL

        # Get model matrix
        factors.data.respondent <- colnames(data.respondent)[sapply(data.respondent, is.factor)]
        data.coded <- model.matrix(~., data.respondent)
        # Remove the intercept
        data.coded <- data.coded[, -1]
        # Pass only the variabeles, not the ids
        fit.hb <- ChoiceModelR:::choicemodelr(data = data, demos = data.coded, xcoding = xcoding, mcmc=mcmc, options = options,  ...)
    }
    # Format components
    resp.ids <- unique(data$resp.id)
    var.coding <- .GetVarCoding(factor.levels, var.order, xcoding, none = options$none)
    fit.hb$compdraw <- .FormatCompdraw(fit.hb$compdraw, var.coding)
    fit.hb$betadraw <- .FormatBetadraw(fit.hb$betadraw, var.level = var.coding$var.level, resp.ids, factor.levels)

    # Format deltadraws
    if(!invalid(data.respondent))
        fit.hb$compdraw <- FormatDeltadraws(fit.hb, data.coded)

    # Add factor levels details
    fit.hb$factors <- factor.levels
    # Add the mean and var-cov for the reference levels
    if(get.coefs.ref.level == TRUE){
        print("Calculating the coefficients for the reference levels (might take some time)")
        fit.hb$compdraw_ref <- mclapply(fit.hb$compdraw, GetPopulationEstimatesWithRefLevels, var.coding, factor.levels, mc.cores = mc.cores)
        # Reorder the betadraws according to mu
        fit.hb$betadraw <- fit.hb$betadraw[ ,c("resp.id", attr(fit.hb$compdraw_ref[[1]]$mu, "name")), with=FALSE]

    }
    # Return
    fit.hb
}

#' Gets the factors, factor level, binding of the factor names with levels, etc, in the order they appear in the data.
#'
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#' @param var.order the list of variables used in the estimation, ordered as they will be used in choicemodelr
#' @param xcoding = binary vector, takes 1 for the numeric variables and 0 for the factor variables
#'
#' @author Radu Tanase
.GetVarCoding <- function(factor.levels, var.order, xcoding, none=TRUE){
     # Create the variable names for factors, numeric, none
    factors <- sapply(var.order[xcoding==0], function(x) length(factor.levels[[x]]$levels))
    factors <- rep(var.order[var.order %in% names(factors)], factors-1)
    all.variables <- c(factors, var.order[xcoding==1])
    if(none==TRUE)
        all.variables <- c(all.variables, "none")

    # Get the levels, repeated by the number of factors
    level <- unlist(sapply(var.order[var.order %in% factors], function(x) factor.levels[[x]]$levels[!factor.levels[[x]]$levels %in% factor.levels[[x]]$ref_level]))
    level <- as.character(level)

    # Add the number
    var.level <- c(paste(factors, level, sep=""), var.order[xcoding==1])
    if(none==TRUE)
        var.level <- c(var.level, "none")

    # Add the full variables, including the reference levels
    factors.with.ref <- sapply(var.order[xcoding==0], function(x) length(factor.levels[[x]]$levels))
    factors.with.ref <- rep(var.order[var.order %in% factors], factors.with.ref)
    level.with.ref <- unlist(sapply(var.order[var.order %in% factors], function(x) c(factor.levels[[x]]$levels[!factor.levels[[x]]$levels %in% factor.levels[[x]]$ref_level], factor.levels[[x]]$levels[factor.levels[[x]]$levels %in% factor.levels[[x]]$ref_level])))
    level.with.ref <- as.character(level.with.ref)

    var.level.with.ref <- c(paste(factors.with.ref, level.with.ref, sep=""), var.order[xcoding==1])
    if(none==TRUE)
        var.level.with.ref <- c(var.level.with.ref, "none")
    list(all.variables=all.variables, factors=factors, level=level, var.level=var.level, var.level.ref=var.level.with.ref)
}

#' Adds names as attributes to the compdraw component of the choicemodelr result. I.e. adds the variables as column and row names.
#'
#' @param compdraw compdraw component of the choicemodelr output.
#' @param var.coding output of .GetVarCoding
#'
#' @author Radu Tanase
.FormatCompdraw <- function(compdraw, var.coding, deltadraw=NULL, data.coded=NULL){
    # Add names as attributes
    compdraw <- lapply(compdraw, .SetAttributesMu, all.variables = var.coding$all.variables, level=var.coding$level, var.level=var.coding$var.level)
    compdraw <- lapply(compdraw, .SetAttributesRooti, all.variables = var.coding$all.variables, level=var.coding$level, var.level=var.coding$var.level)
}

#' Formats the deltadraw component of the choicemodelr result
#' @param fit.hb output of FitHB
#' @param data.coded
#'
#' @author Radu Tanase
FormatDeltadraws <- function(fit.hb, data.coded){
    # Format delta draws and add them to compdraw if present
    if(nrow(fit.hb$deltadraw) != length(fit.hb$compdraw)) stop("nrow of deltadraw does not match nrow of compdraw")
    foreach(i = 1:nrow(fit.hb$deltadraw)) %do% {
        deltas <- matrix(fit.hb$deltadraw[i, ], nrow=length(colnames(data.coded)), byrow=TRUE)
        colnames(deltas) <- attr(fit.hb$compdraw[[1]]$mu, "name")
        rownames(deltas) <- colnames(data.coded)
        # Add to compdraw
        fit.hb$compdraw[[i]]$deltadraw <- deltas
    }
    fit.hb$compdraw
}

#' Adds names as attributes to the betadraw component of the choicemodelr result. I.e. adds the variables as column and row names.
#'
#' @param betadraw betadraw component of the choicemodelr output.
#' @param var.level the var.level element of the output of .GetVarCoding. It's basically the full names of the variables, created by pasting the variable name and the level for the factor variables.
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#' @param var.order.levels order of variables, including the levels. Same as in mu

#' @author Radu Tanase
.FormatBetadraw <- function(betadraw, var.level, resp.ids, factor.levels, var.order.levels){
    # Put all draws in a table
    res <- foreach(i = 1:dim(betadraw)[1]) %do% {
        cbind(resp.id = resp.ids[i], data.table(t(betadraw[i,,])))
    }
    res <- rbindlist(res)
    # Rename
    names(res) <- c("resp.id", var.level)
    # Add reference levels
    for(i in names(factor.levels)){
        # Get the reference level
        ref.level <- factor.levels[[i]]$ref_level_name
        remaining.levels <- factor.levels[[i]]$variable_name
        remaining.levels <- remaining.levels[remaining.levels!=ref.level]
        # Compute the coefficient (as minus the sum of all the other levels)
        res$ref_level <- - apply(res[, remaining.levels, with=FALSE], 1, sum)
        setnames(res, "ref_level", ref.level)
    }
    res <- res[, var.order.levels, with=FALSE]
}

#' Adds names as attributes to the mu component of the compdraw. I.e. adds the variables as column names.
#'
#' @param x mcmc draw from compdraw
#' @param all.variables level var.level ->  elements of the output of .GetVarCoding
#'
#' @author Radu Tanase
.SetAttributesMu <- function(x, all.variables, level, var.level){
    attr(x$mu, "variable") <- all.variables
    attr(x$mu, "level") <- level
    attr(x$mu, "name") <- var.level
    x
}

#' Adds names as attributes to the rooti component of the compdraw. I.e. adds the full variable names (variable + level in case of factors) as column and row names. It also adds only the variables under the attribute "dim_variables".
#'
#' @param x mcmc draw from compdraw
#' @param all.variables level var.level ->  elements of the output of .GetVarCoding
#'
#' @author Radu Tanase
.SetAttributesRooti <- function(x, all.variables, level, var.level){
    rownames(x$rooti) <- colnames(x$rooti) <- var.level
    attr(x$rooti, "dim_variables") <- list(rows = all.variables, cols = all.variables)
    x
}

#' Checks if an object is invalid. An object is invalid if it is missing, NULL, of length 0 or (if vector) all NA or (if list) all elements are invalid
invalid <- function (x)
{
  if (missing(x) || is.null(x) || length(x) == 0)
    return(TRUE)
  if (is.list(x))
    return(all(sapply(x, invalid)))
  else if (is.vector(x))
    return(all(is.na(x)))
  else return(FALSE)
}
