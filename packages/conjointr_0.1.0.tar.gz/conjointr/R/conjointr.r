#' conjointr: A package for to estimate choice models using HB based on ChoiceModelR
#'
#' @docType package
#' @name conjointr
NULL
