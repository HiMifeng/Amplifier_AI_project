################################################################################
# Copyright (c) 2025. All rights reserved.  See the file LICENSE for
# license terms.
################################################################################

# File: get_coefs_ref_levels.r
# Proj: conjointr
# Desc: Functions used to get the reference levels
# Auth: Radu Tanase (RT)
# Last update: Sept 2025

################################################################################

#' Get the population means, including the coefficients for the reference levels
#'
#' @param x mcmc draw from compdraw
#' @param var.coding output of .GetVarCoding
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#'
#' @author Radu Tanase
#' @export
GetMuWithRefLevels <- function(x, var.coding, factor.levels){
    # Initialise the vector to store all the population means
    mu <- numeric(length(var.coding$var.level.ref))
    attr(mu, "name") <- var.coding$var.level.ref
    # Add the initial estimates
    foreach(i = var.coding$var.level) %do% {
        mu[attr(mu, "name")==i] <- x$mu[attr(x$mu, "name")==i]
    }
    # Add the reference levels
    mu.ref.levels <- .GetMuRefLevels(x, factor.levels)
    foreach(i = mu.ref.levels$name) %do% {
        mu[attr(mu, "name")==i] <- mu.ref.levels[name==i]$coef
    }
    mu
}

#' Get the population means for the reference levels
#'
#' @param x mcmc draw from compdraw
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#'
#' @author Radu Tanase
.GetMuRefLevels <- function(x, factor.levels){
    # For every attribute
    res <- foreach(i = names(factor.levels)) %do% {
        # Get the reference level
        ref.level <- factor.levels[[i]]$ref_level
        # Compute the coefficient
        coef.ref.level <- - sum(x$mu[attr(x$mu, "variable") == i])
        data.table(variable = i, level = ref.level, name = paste(i, ref.level, sep=""), coef = coef.ref.level)            }
    rbindlist(res)
}

#' Get the population covariance matrix, including the coefficients for the reference levels
#'
#' @param x mcmc draw from compdraw
#' @param var.coding output of .GetVarCoding
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#'
#' @author Radu Tanase
#' @export
GetCovWithRefLevels <- function(x, var.coding, factor.levels){
    # Make the initial covariance symmetric, but preserve the attributes
    rooti <- crossprod(x$rooti)
    attr(rooti, "dim_variables") <- attr(x$rooti, "dim_variables")
    # Get the referene levels
    ref.levels <- as.character(sapply(factor.levels, function(x) paste(x$variable, x$ref_level, sep="")))
    # Get the dim of the covariance matrix
    covmat.dim <- length(var.coding$all.variables) + length(ref.levels)
    # Initialise the covariance matrix
    covmat <- matrix(numeric(), nrow = covmat.dim, ncol = covmat.dim)
    # Set dimension names
    colnames(covmat) <- rownames(covmat) <- c(var.coding$var.level, ref.levels)

    # Add the entries initially estimated
    foreach(j = colnames(rooti)) %do% {
        foreach(i = rownames(rooti)) %do% {
            covmat[rownames(covmat) == i, colnames(covmat)==j] <- as.numeric(rooti[rownames(rooti) == i, colnames(rooti)==j])
        }
    }

    # Get the covariances between the reference levels and all variables, except the other reference levels
    tmp1 <- .GetMissingCovsNoRef(mat=rooti, factor.levels)
    # Store also the reverse order (to make the matrix symmetric)
    tmp2 <- copy(tmp1)
    setnames(tmp2, c("source", "target"), c("target", "source"))
    tmp <- rbind(tmp1, tmp2, use.names = TRUE)

    tmp3 <- .GetMissingCovsRefLevels(mat=rooti, factor.levels)
    tmp <- rbind(tmp, tmp3) # The edgelist is already symmetric

    # Fill out the missing covariance entries
    foreach(i = 1:nrow(tmp)) %do% {
        covmat[rownames(covmat) == tmp$source[i], colnames(covmat) == tmp$target[i]]  <- tmp$cov[i]
    }

    # Arrange according to the variable order
    covmat[var.coding$var.level.ref, var.coding$var.level.ref]
}


#' Get the covariance entries of the reference levels with all other coefficients, except other reference levels
#'
#' @param mat the covariance matrix, as estimated by choicemodelr (under compdraw[[]]$rooti
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#'
#' @author Radu Tanase
#' @export
.GetMissingCovsNoRef <- function(mat, factor.levels){
    res <- foreach(j = names(factor.levels)) %do% {
        focal.factor <- factor.levels[[j]]
        tmp.res <- foreach(i = colnames(mat)) %do%{
            # Get the focal variables (all except the reference levels of the other factors
            focal.variable <- i
            # Get the covariance between the focal variable and all the levels of the factor (except the reference)
            tmp.covs <- mat[attr(mat, "dim_variables")$rows == j , colnames(mat)==focal.variable]
            # The covariance between the ref level and the focal variable is the negative sum of these covariances
            data.table(source = paste(j, focal.factor$ref_level, sep=""), target = focal.variable, cov = -sum(tmp.covs))
        }
        rbindlist(tmp.res)
    }
    rbindlist(res)
}

#' Get the covariance entries of the reference levels with all other reference levels only.
#'
#' @param mat the covariance matrix, as estimated by choicemodelr (under compdraw[[]]$rooti
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#'
#' @author Radu Tanase
#' @export
.GetMissingCovsRefLevels <- function(mat, factor.levels){
    res <- foreach(j = names(factor.levels)) %do% {
        tmp.res <- foreach(i = names(factor.levels)) %do%{
            # Get the focal variables (all except the reference levels of the other factors
            # Get the covariance between the focal variable and all the levels of the factor (except the reference)
            tmp.covs <- mat[attr(mat, "dim_variables")$rows == i , attr(mat, "dim_variables")$cols == j]
            # The covariance between the ref level and the focal variable is the negative sum of these covariances
            data.table(source = paste(j, factor.levels[[j]]$ref_level, sep=""), target = paste(i, factor.levels[[i]]$ref_level, sep=""), cov = sum(tmp.covs))
        }
        rbindlist(tmp.res)
    }
    rbindlist(res)
}

#' Get the population means and covariance matrix, including the coefficients for the reference levels
#'
#' @param x mcmc draw from compdraw
#' @param var.coding output of .GetVarCoding
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#'
#' @author Radu Tanase
#' @export
GetPopulationEstimatesWithRefLevels <- function(x, var.coding, factor.levels){
    mu <- GetMuWithRefLevels(x, var.coding, factor.levels)
    covmat <- GetCovWithRefLevels(x, var.coding, factor.levels)
    if(!invalid(x$deltadraw)){
        deltadraw <- GetDeltadrawWithRefLevels(x, factor.levels, mu)
        list(mu = mu, rooti=covmat, deltadraw = deltadraw)
    } else {
        list(mu = mu, rooti=covmat)
    }
}


#' Get the deltadraws including for the reference levels
#'
#' @param x mcmc draw from compdraw
#' @param mu vector of population means, including the reference levels. Needs to contain the "name" attribute
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#'
#' @author Radu Tanase
#' @export
GetDeltadrawWithRefLevels <- function(x, factor.levels, mu){
    # Initialise the vector to store all the population means
    deltadraw <- matrix(NA, nrow = nrow(x$deltadraw), ncol = length(mu))
    rownames(deltadraw) <- rownames(x$deltadraw)
    colnames(deltadraw) <- attr(mu, "name")

    # Add the initial estimates
    foreach(i = rownames(x$deltadraw)) %do% {
        foreach(j = colnames(x$deltadraw)) %do% {
            deltadraw[rownames(deltadraw)==i, colnames(deltadraw)==j] <- x$deltadraw[rownames(x$deltadraw)==i, colnames(x$deltadraw)==j]
        }
    }
    # Add the reference levels
    deltadraw.ref.levels <- .GetDeltadrawRefLevels(x, factor.levels)
    foreach(i = 1:nrow(deltadraw.ref.levels)) %do% {
        deltadraw[rownames(deltadraw)==deltadraw.ref.levels$source[i], colnames(deltadraw)==deltadraw.ref.levels$target[i]] <- deltadraw.ref.levels$coef[i]

    }
    # Make sure the initial order is preserved
    deltadraw[rownames(x$deltadraw), attr(mu, "name")]
}

#' Get the deltadraws including for the reference levels
#'
#' @param x mcmc draw from compdraw
#' @param factor.levels list, each entry corresponds to a factor and contains the name (variable) the levels and the reference level (ref_level)
#'
#' @author Radu Tanase
#' @export
.GetDeltadrawRefLevels <- function(x, factor.levels){
    res <- foreach(i = rownames(x$deltadraw)) %do% {
        tmp.res <- foreach(j = names(factor.levels)) %do% {
            # Get the coefficients for all levels except the reference level and take the neg sum
            coef.ref.level <- -sum(x$deltadraw[rownames(x$deltadraw)==i, colnames(x$deltadraw) %in% factor.levels[[j]]$variable_name])
            # Return
            data.table(source = i, target = factor.levels[[j]]$ref_level_name, coef = coef.ref.level)
        }
        rbindlist(tmp.res)
    }
    rbindlist(res)
}
