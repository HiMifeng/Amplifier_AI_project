#' Get Choice By Price
#'
#' Compute the choice ratio as function of price
#'
#' @param profiles Product profiles, matrix with each line in the conjointr structure (ques, alt, var1, var2, ..., price)
#' @param fit.hb data.table with the results of the hb estimation (betadraws) in sawtooth format.
#' @param hb.formula Variables in the model, in the form: "~ none + type + cooking_time + cooking_skills + price"
#' @param predictors Vector with the names of the predictors columns, without the price.
#' @param price.variables Vector with the name of the price columns,
#' @export
#' @author Radu Tanase
#' @return data.table with resp.id, choice_ratio (averaged over products) and price_level
GetChoiceByPrice <- function(profiles, fit.hb, hb.formula, predictors, price.variables){
    # Define profile matrix
    profiles.matrix <- model.matrix(as.formula(hb.formula), profiles)[, -1] # -1 is to remove the intercept
    # Get all users
    users <- unique(fit.hb$resp.id)
    res <- foreach(k = price.variables) %do% {
        # Set price level
        price.level= k
        # For each user
        res.users <- foreach(i = 1:length(users)) %dopar% {
            user <- users[i]
            # Get the draws corresponding to each user
            draws.id <- fit.hb[resp.id==user]
            # For each profile
            res.products <- foreach(j = 1:nrow(profiles.matrix)) %do% {
                # Define the product
                product = profiles.matrix[j,]
                # Probability for a user to buy the product
                mean(apply(draws.id, 1, .ChoiceByPrice, product, predictors, price.level))
            }
            # Average probability (over products) that the user buy at this price level
            data.table(resp.id = user, choice_ratio = mean(unlist(res.products)), price_level = price.level)
        }
        print(price.level)
        rbindlist(res.users)
        # Choice ratio for price level over all products
    }
    rbindlist(res)
}

#' Get Choice By Price
#'
#' Compute the choice ratio for one draw
#'
#' @param draw one posterior draw from one user
#' @param product Product profile, in the conjointr structure (ques, alt, var1, var2, ..., price)
#' @param predictors Vector with the names of the predictors columns, without the price.
#' @param price.level Vector with the name of the price column, for which to compute the choice_ratio
#' @author Radu Tanase
#' @return data.table with resp.id, choice_ratio (averaged over products) and price_level
.ChoiceByPrice <- function(draw, product, predictors, price.level){
    # browser()
    # Compute utility of none
    utility.none <- draw["none"]
    # Compute utility of profile without price
    profile.utility <- sum(draw[predictors] %*% product[predictors])
    # Compare against the price utility
    profile.utility + draw[price.level] > utility.none
}


#' Get InSample Prediction Accuracy
#'
#' Compute the in sample prediction accuracy by predicting the choice for each question
#'
#' @param data Product profiles, matrix with each line in the conjointr structure (ques, alt, var1, var2, ..., choice, none, price). The column choice should contain the alternative chosen, while the column (one non zero entry for each question) and the column none should contain a 1 in the row corresponding to the none option and zero otherwise.
#' @param fit.hb data.table with the results of the hb estimation (betadraws) in sawtooth format.
#' @param hb.formula Variables in the model, in the form: "~ none + type + cooking_time + cooking_skills + price"
#' @export
#' @author Radu Tanase
#' @return data.table with utility = mean utility of the profile (over draws), 5% and 95% quantiles
GetInSamplePredictionAccuracy <- function(data, fit.hb, hb.formula){
    res <- foreach(i = unique(data$ques)) %do%{
        GetPredictionAccuracy(data, fit.hb, hb.formula, ques.holdout=i)
    }
    mean(unlist(res))
}

#' Get Prediction Accuracy
#'
#' Compute the prediction accuracy on a holdout sample
#'
#' @param data Product profiles, matrix with each line in the conjointr structure (ques, alt, var1, var2, ..., choice, none, price). The column choice should contain the alternative chosen, while the column (one non zero entry for each question) and the column none should contain a 1 in the row corresponding to the none option and zero otherwise.
#' @param fit.hb data.table with the results of the hb estimation (betadraws) in sawtooth format.
#' @param hb.formula Variables in the model, in the form: "~ none + type + cooking_time + cooking_skills + price"
#' @param ques.holdout ID of the question used as holdout (value of col ques in the data argument).
#' @export
#' @author Radu Tanase
#' @return data.table with utility = mean utility of the profile (over draws), 5% and 95% quantiles
GetPredictionAccuracy <- function(data, fit.hb, hb.formula, ques.holdout){
    # The profiles to be evaluated are those corresponding to the holdout question
    profiles <- data[ques == ques.holdout]

    res <- foreach(i = unique(profiles$resp.id)) %dopar% {
        # Subset profiles for one user
        tmp.profiles <- profiles[resp.id==i & none==0]
        # Subset betadraws
        betadraws <- fit.hb[resp.id==i]
        # Get utility of none
        utility.none <- mean(betadraws$none)
        # Predict utilities
        utilities <- PredictUtilities(tmp.profiles, hb.formula, betadraws)
        # Was the product with the highest utility selected?
        (which.max(utilities$utility) == max(tmp.profiles$choice)) | (max(utilities$utility) <= utility.none &  max(tmp.profiles$choice)>max(tmp.profiles$alt)) # Corresponding to the none option
    }
    mean(unlist(res))
}


#' Predict Utilities
#'
#' Get the ulilities for multiple product
#'
#' @param profiles Product profiles, matrix with each line in the conjointr structure (ques, alt, var1, var2, ..., price)
#' @param hb.formula Variables in the model, in the form: "~ none + type + cooking_time + cooking_skills + price"
#' @param betadraws Posterior draws for each of the model variables, for one respondent
#' @export
#' @author Radu Tanase
#' @return data.table with utility = mean utility of the profile (over draws), 5% and 95% quantiles
PredictUtilities <- function(profiles, hb.formula, betadraws){
    res <- foreach(i = 1:nrow(profiles)) %do% {
      PredictProfileUtility(profiles[i], hb.formula, betadraws)
    }
    rbindlist(res)
}


#' Predict profile utility
#'
#' Get the utility for one product
#'
#' @param profile Product profile, in the conjointr structure (ques, alt, var1, var2, ..., price)
#' @param hb.formula Variables in the model, in the form: "~ none + type + cooking_time + cooking_skills + price"
#' @param betadraws Posterior draws for each of the model variables, for one respondent
#' @export
#' @author Radu Tanase
#' @return data.table with utility = mean utility of the profile (over draws), 5% and 95% quantiles
PredictProfileUtility  <- function(profile, hb.formula, betadraws) {
    # Create the model matrix
    data.model <- model.matrix(as.formula(hb.formula), data = profile)
    data.model <- data.model[,-1] # remove the intercept

    # Compute the utilities for each draw
    res <- data.model %*% t(as.matrix(betadraws[, attr(data.model, "names"), with=FALSE]))

    # Average over draws
    utility.mean <- mean(res)
    utility.q05 <- quantile(res, probs=0.05)
    utility.q95 <- quantile(res, probs=0.95)

    # Return
    data.table(utility = utility.mean, q05 = utility.q05, q95 = utility.q95)
}
