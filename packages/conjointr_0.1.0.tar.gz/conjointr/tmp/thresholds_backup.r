#' Get the wtp (adoption threshold) for one product using the model estimated by sawthooth
#'
#' @param product product profile
#' @param product.name unique identifier for the product profile. It is not used in the calculation, only in the output.
#' @param betadraw data.table with the betadraws for each respondent / profile (e.g., as outputed by the Sawthooth software)
#' @param predictors vector with the names of the attributes columns, except price
#' @param price list with: type = either linear or partworth, variables = price.variables vector with the names of the price columns, values = price.values vector with price levels. Should be sorted the same as the price variables
#' @param keep integer,
#' @author Radu Tanase
#' @export
#' @details For an explanation of the methodology, see Miller, K. M., Hofstetter, R., Krohmer, H., & Zhang, Z. J. (2011). How Should Consumers’ Willingness to Pay Be Measured.
GetWTPBetadraw <- function(product, product.name, betadraw, predictors, price, constrain_linear=TRUE){
  # Compute WTP for each respondent
  users <- unique(betadraw$resp.id)
  wtp <- foreach(i = 1:length(users)) %do% {
    # Get respondent utilities
    draws.id <- betadraw[resp.id==users[i]]
    # Compute WTP
    wtp <- apply(draws.id, 1, .GetWTP, product, predictors, price, constrain_linear)
    data.table(resp.id = users[i], profile = product.name, wtp=wtp)
  }
  rbindlist(wtp) # ads
}

#' Get the wtp (adoption threshold) for one product using the model estimated by sawthooth
#'
#' @param fit.hb the results of \code{FitHB}
#' @param n number of samples to draw from the multivariate normal distribution at each mcmc draw
#' @param product product profile
#' @param product.name unique identifier for the product profile. It is not used in the calculation, only in the output.
#' @param predictors vector with the names of the attributes columns, except price
#' @param price list with: type = either linear or partworth, variables = price.variables vector with the names of the price columns, values = price.values vector with price levels. Should be sorted the same as the price variables
#' @param contrain_linear if the wtp should be mapped to 0-1 (values outside the range take the extremes)
#' @param covariates vector with the names of the covariastes (demos) to use in the estimation
#' @param keep how many of the draws to keep. E.g., default is to keep each 10th draw.
#' @author Radu Tanase
#' @export
GetWTPCompdraw <- function(fit.hb, n, product, product.name, predictors, price, constrain_linear=TRUE, covariates = NULL, keep=10){
  # Get the draws to use. We can use only a subset to reduce computational effort
  draws <- seq(1, length(fit.hb$compdraw_ref), by=keep)
  res <- foreach(i = draws) %do%{
    # Simulate respondents for this draw
    data.sim <- SamplePopModel(n, fit.hb$compdraw_ref[[i]], covariates = covariates)
    wtp <- apply(data.sim, 1, .GetWTP, product, predictors, price, constrain_linear)
    data.table(draw = i, profile = product.name, wtp=wtp)
  }
  rbindlist(res)
}

