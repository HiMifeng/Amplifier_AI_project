#' Get all column names relevant to the conjoint answers
#'
#' @param choice.variable.name Name of the choice question in Qualtrics
#' @param nr.choices Nr of choices in the conjoint study
#' @export
#' @author Radu Tanase
GetConjointColumns <- function(choice.variable.name, nr.choices){
    # Get selected choices
    selected.choices <- paste(choice.variable.name, 1:nr.choices, "_0_GROUP", sep="")
    # Get unselected choices
    unselected.choices <- paste(choice.variable.name, 1:nr.choices, "_1_GROUP", sep="")
    # Return both
    c(selected.choices, unselected.choices)
}

#' Format data based on own implementation of conjoint survey in qualtrics
#'
#' @param data data imported from qualtrics csv
#' @param profiles profile table used for the conjoint study
#' @param choice.variable.name Name of the choice question in Qualtrics
#' @param nr.choices Nr of choices in the conjoint study
#' @export
#' @author Radu Tanase
FormatDataConjoint <- function(data, profiles, choice.variable.name, nr.choices){
    # Define questions related to the conjoint
    questions <- paste(choice.variable.name, 1:nr.choices, sep="")
    # Format
    res <- foreach(i = questions) %do% {
        .FormatQuestion(question = i, data, items)
    }
    res <- rbindlist(res)

    # Keep only ids with all answers (otheriwse might be an issue with the demographics
    tmp <- res[, length(ques), by=resp.id]
    tmp[order(V1)]
    # How many do we remove
    print(paste(nrow(res[resp.id %in% tmp[V1!=max(tmp$V1)]$resp.id])/nrow(res)*100,  "% of observations removed because two items have been chosen"))

    res <- res[resp.id %in% tmp[V1==max(tmp$V1)]$resp.id]

    # Convert IDS to numeric
    tmp.ids <- data.table(OriginalID=data$ID, ID=1:nrow(data))
    data$ID <- 1:nrow(data)
    res <- merge(res, tmp.ids, by.x="resp.id", by.y="OriginalID")
    setnames(res, c("ID", "resp.id"), c("resp.id", "OriginalID"))

    # Reorder
    # defaults <- c("res.id", "ques", "alt", "choice", "alt_text")
    # colnames(res)[!colnames(res) %in%]
    res
}

#' Format question based on own implementation of conjoint survey in qualtrics
#'
#' @param question question to format
#' @param data data imported from qualtrics csv
#' @param items items profile table used for the conjoint study
#' @export
#' @author Radu Tanase
.FormatQuestion <- function(question, data, items){
    res <- foreach(i = 1:nrow(data)) %do% {
     # Subset data
        tmp <- data[i]
        # Create choice variable
        question.choice <- paste(question, "_0_GROUP", sep="")
        choice <- as.character(sapply(tmp[, get(question.choice)], function(x) unlist(strsplit(x,","))))
        # Create the alternatives
        question.alternative <- paste(question, "_1_GROUP", sep="")
        alt <- sapply(tmp[, get(question.alternative)], function(x) unlist(strsplit(x,",")))
        # Add none
        if((!"None" %in% choice) & (!"None" %in% alt) & length(alt)==1){
            alt <- c(alt, "None")
        }

        if(length(choice)==1 & length(alt)==2){
            # Randomize order (otherwise choicemodelr will fail)
            # Format output
            rand.order <- sample(1:3, 3)
            shown.alt <- c(choice, alt)
            shown.alt <- shown.alt[rand.order]

            # Add None on the last place
            shown.alt <- c(shown.alt[shown.alt!="None"], "None")

            selected.choice <- which(shown.alt==choice)
            selected.choice <- c(selected.choice, 0, 0) # c(rep(0, selected.choice-1), selected.choice, rep(0, 3-selected.choice))

            res <- data.table(resp.id=tmp$ID, ques = as.numeric(unlist(strsplit(question, "Choice"))[2]), alt = 1:3, none = c(0,0,1), choice=selected.choice, alt_text = shown.alt) # without none
            # merge(res, items, by.x="alt_text", by.y = "item", all.x=TRUE)

        } else {
            # print(length(alt))
            print("observation removed because repondent has selected 2 choices")
            NULL
        }

    }
    rbindlist(res)
}

#' Recode 5 items agreement likert scale
#'
#' @param x the item to code
#' @export
#' @author Radu Tanase
Recode <- function(x, reverse=FALSE){
    if(reverse==FALSE){
        if(x=="Strongly agree") res <- 5
        if(x=="Somewhat agree") res <- 4
        if(x=="Neither agree nor disagree") res <- 3
        if(x=="Somewhat disagree") res <- 2
        if(x=="Strongly disagree") res <- 1
    }
    if(reverse==TRUE){
        if(x=="Strongly agree") res <- 1
        if(x=="Somewhat agree") res <- 2
        if(x=="Neither agree nor disagree") res <- 3
        if(x=="Somewhat disagree") res <- 4
        if(x=="Strongly disagree") res <- 5
    }
    res
}

RecodeIncome <- function(x){
    if(x == "Under $25,000") res <- 1
    if(x == "$25,001 - $49,999") res <- 1
    if(x == "$50,000 - $74,999") res <-2
    if(x == "$75,000 - $99,999") res <-2
    if(x == "$100,000 - $149,000") res <- 3
    if(x == "$150,000 - $249,999") res <- 3

    res
}


# Willingness to pay
# =================================================================================
#' Get the wtp for multiple respondents and draws.
#'
#' @param product product profile
#' @param product.name unique identifier for the product profile. It is not used in the calculation, only in the output.
#' @param fit.hb The results of the HB estimation using choicemodelr. It is the output of \code{FitHB}.
#' @param resp.id id of the respondent for which the wtp is computed. It is not used in the calculation, only in the output. Needs to be sorted the same way as the input data for the HB analysis.
#' @param price.pos position of the price variables in the product profile
#' @param price.values values of the price attribute
#' @author Radu Tanase
#' @export
GetWTP <- function(product, product.name, fit.hb, resp.id, price.pos, price.values){
    # browser()
    # Compute WTP for each respondent
    wtp <- foreach(i = 1:dim(fit.hb$betadraw)[1]) %do% {
    # Get respondent utilities
        draws.id <- fit.hb$betadraw[i,,]
        tmp.resp.id <- resp.id[i]
        if(i %% 100==0)
            print(paste(i, "out of 1000 draws ready"))
        .GetWTPID(draws.id, tmp.resp.id, product, product.name, price.pos, price.values)
    }
    rbindlist(wtp)
}


#' Get the wtp for multiple draws for the same respondent
#'
#' @param draws.id the MCMC draws for one respondent. They are the betadraw entries in the output of \code{FitHB} for one respondent (\code{fit.hb$betadraw[i,,]})
#' @param resp.id id of the respondent for which the wtp is computed. It is not used in the calculation, only in the output.
#' @param product product profile
#' @param product.name unique identifier for the product profile. It is not used in the calculation, only in the output.
#' @param price.pos position of the price variables in the product profile
#' @param price.values values of the price attribute
#' @author Radu Tanase
.GetWTPID <- function(draws.id, resp.id, product, product.name, price.pos, price.values){
    res <- apply(draws.id, 2, .GetWTPDraw, product, price.pos, price.values)
    data.table(resp.id = resp.id, profile = product.name, wtp=res)
}

#' Get the wtp (adoption threshold) for one draw
#'
#' @param draw MCMC draw for one respondent, as outputed from \code{FitHB}. Assumes the first value corresponds to none.
#' @param product product profile
#' @param price.pos position of the price variables in the product profile
#' @param price.values values of the price attribute
#' @author Radu Tanase
#' @details For an explanation of the methodology, see Miller, K. M., Hofstetter, R., Krohmer, H., & Zhang, Z. J. (2011). How Should Consumers’ Willingness to Pay Be Measured.
.GetWTPDraw <- function(draw, product, price.pos, price.values){
    # Compute utility of none
    utility.none <- draw[1]

    # Compute utility of profile without price
    profile.utility <- sum(draw[c(!price.pos, 1)] %*% product[c(!price.pos, 1)]) # 1 is for excluding none dummy

    # Create data for inverse utility for all price levels
    input <- sortedXyData(x=price.values , y=draw[price.pos])

    # Compute WTP
    wtp <- NLSstClosestX(input, (utility.none - profile.utility))

    # Return
    wtp
}


# Difference in WTP
# ========================================================================================
GetWTPDiff <- function(product1, product2, product1.name, product2.name, fit.hb, resp.id){
    # Compute WTP for each respondent
    wtp <- foreach:::foreach(i = 1:dim(fit.hb$betadraw)[1]) %do% {
    # Get respondent utilities
        draws.id <- fit.hb$betadraw[i,,]
        tmp.resp.id <- resp.id[i]
        if(i %% 100==0)
            print(paste(i, "out of 1000 draws ready"))
        .GetWTPIDDiff(draws.id,tmp.resp.id, product1, product2, product1.name, product2.name)
    }
    rbindlist(wtp)
}

.GetWTPIDDiff <- function(draws.id, resp.id, product1, product2, product1.name, product2.name){
    res.p1 <- apply(draws.id, 2, .GetWTPDraw, product1)
    res.p2 <- apply(draws.id, 2, .GetWTPDraw, product2)
    res <- res.p1-res.p2
    res.mean <- mean(res)
    q05 <- quantile(res, probs=0.05)
    q95 <- quantile(res, probs=0.95)
    data.table:::data.table(resp.id = resp.id, profile1 = product1.name, profile2 = product2.name, wtp.diff=res.mean, wtp.diff.q05 = q05, wtp.diff.q95=q95)
}


#' NOT WORKING Fit hierarchical bayes model using the ChoiceModelR package
#'
#' @param question question to format
#' @param data data imported from qualtrics csv
#' @param items items profile table used for the conjoint study
#' @export
#' @importFrom ChoiceModelR choicemodelr
#' @author Radu Tanase
FitHBOwnCoding <- function(formula, data, data.respondent=NULL, mcmc=list(R=5000, use=1000), options = list(save=TRUE, none=FALSE, keep=10)){
    parsed.formula <- as.formula(formula)
    # Get model matrix
    data.coded <- model.matrix(parsed.formula, data)
    # Remove the intercept
    data.coded <- data.coded[, -1]
    # Add resp.id, question, alt
    data.hb <- cbind(data[, list(resp.id, ques, alt)], data.coded)
    data.hb <- cbind(data.hb, choice=data$choice)

    # HB references by col position, so check the order is resp.id, ques, alt, star, type, price, choice
# HB also references by row postion (see help(choicemodelr) so need to ensure data is sorted by resp.id, etc.
    data.hb <- data.hb[order(-resp.id, -ques, choice, decreasing=TRUE)]

    # Create matrix
    data.hb.mat <- as.matrix(data.hb)

    # Create individual level variables
    # -------------------------------------------------------------------------------
    # Convert to matrix format
    # if(!invalid(data.respondent))
        # data.respondent <- as.matrix(data.respondent, rownames = data.respondent$resp.id)

    # Estimate model using HB
    fit.hb <- ChoiceModelR:::choicemodelr(data = data.hb.mat, xcoding = rep(1, ncol(data.coded)), mcmc=mcmc, options=options)

    # Add the variable names
    fit.hb$varnames <- attr(data.coded, "dimnames")[[2]]

    # Return
    fit.hb
}



#' Compute the utility of a product profile for a respondent
#'
#' @param fit.hb model containing the hb estimates. It is the output of \code{FitHB}.
#' @param profile product profile
#' @param ids.pos the position of the respondent in the fit.hb list. Need to ensure is the same in train / test set.
#' @export
#' @author Radu Tanase
PredictUtility <- function(fit.hb, profile, ind.pos) {
    betadraws <- fit.hb$betadraw
   # Function for predicting shares from a hierarchical multinomial logit model
   # betadraws: matrix of betadraws returned by ChoiceModelIR
   # data: a data frame containing the set of designs for which you want to
   #       predict shares.  Same format at the data used to estimate model.

    # Create the model matrix
    data.model <- model.matrix(~ none + type + cooking_time + cooking_skills + price, data = profile)
    data.model <- data.model[,-1] # remove the intercept

    # Get nr of draws
    ndraws <- dim(fit.hb$betadraw)[3]

    # Compute the utilities for each draw
    res <- foreach:::foreach(d = 1:ndraws) %do% {
        # Compute the utility
        data.model %*% betadraws[ind.pos,,d]
    }
    res <- unlist(res)

    # Average over draws
    utility.mean <- mean(res)
    utility.q05 <- quantile(res, probs=0.05)
    utility.q95 <- quantile(res, probs=0.95)

    # Return
    data.table(utility = utility.mean, q05 = utility.q05, q95 = utility.q95)
}
