#' Draws random samples from the population model
#'
#' @param n nr of draws
#' @param compdraw.item one element of compdraw_ref, including the mu, rooti and deltadraw
#' @param covariates = character vector of covariates (optional)
#'
#' @author Radu Tanase
#' @export
SamplePopModel <- function(n, compdraw.item, covariates = NULL){
  # Extract mean and covariance matrix
  pop.mean <- compdraw.item$mu
  pop.cov <- compdraw.item$rooti
  if(!is.null(covariates)){
    # Get the deltadraws
    deltadraw <- compdraw.item$deltadraw
    # Keep only the ones for the required covariates
    deltadraw <- matrix(deltadraw[rownames(deltadraw) %in% covariates, ], ncol = length(pop.mean), byrow=TRUE)
    # Add them to the pop mean
    pop.mean <- pop.mean + apply(deltadraw, 2, sum)
  }

  # Simulate data
  sim.partworhts <- data.table(mvtnorm:::rmvnorm(n = n, mean = pop.mean, sigma = pop.cov))
  names(sim.partworhts) <- attr(compdraw.item$mu, "name")
  # Return
  sim.partworhts
}
