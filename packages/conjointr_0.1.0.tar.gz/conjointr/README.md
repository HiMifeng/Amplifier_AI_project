# conjointr
R code for estimating CBC conjoint using hierarchical bayes.

# How to install

# How to run
Install libraries
`library(conjointr)`
`library(data.table)`

Load some demo data
`data(datar)`

Adapt the input. This should be a data table object containing the columns `resp.id`, `ques`, `alt`, `price`, `choice` and all other variables (here denoted by `x`). The factors should be transformed accordingly. 
`data <- data.table(datar)`
`setnames(data, names(data), c("resp.id", "ques", "alt", "x1", "price", "choice"))`
`data[, x1:=as.factor(x1)]`
`data[, price:=as.factor(price)]`
`head(data)`

Create 

fit.hb <- FitHB(data, data.respondent = data.respondent[, list(resp.id, Gender, susceptibility, recipe)], mc.cores=6, mcmc=list(R=20000, use=10000))
